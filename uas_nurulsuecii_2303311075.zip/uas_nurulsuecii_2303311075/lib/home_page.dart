import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'berita_page.dart';
import 'profil_page.dart';

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _currentIndex = 0;

  // List halaman untuk Bottom Navigation [Home, Berita, Profil]
  final List<Widget> _children = [
    const HomeChildPage(),
    const BeritaPage(),
    const ProfilPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _children[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.article), label: 'Berita'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }
}

// Konten khusus untuk halaman Home (Menampilkan 5 Berita)
class HomeChildPage extends StatefulWidget {
  const HomeChildPage({super.key});

  @override
  State<HomeChildPage> createState() => _HomeChildPageState();
}

class _HomeChildPageState extends State<HomeChildPage> {
  List news = [];

  Future<void> fetchHomeNews() async {
    final response = await http.get(Uri.parse('https://fakenews.squirro.com/news/sport'));
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      setState(() {
        // Mengambil hanya 5 data teratas sesuai instruksi soal
        news = data['news'].take(5).toList();
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchHomeNews();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home - 5 Berita Terbaru')),
      body: news.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: news.length,
        itemBuilder: (context, index) { // <--- PERBAIKAN: Ditambahkan parameter 'index' di sini
          return Card(
            margin: const EdgeInsets.all(8.0),
            child: ListTile(
              title: Text(news[index]['title'] ?? 'No Title', style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(news[index]['summary'] ?? '', maxLines: 2, overflow: TextOverflow.ellipsis),
              leading: const Icon(Icons.sports, color: Colors.blue),
              onTap: () {
                // Menampilkan Detail Berita via Dialog/Modal agar simpel
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text(news[index]['title'] ?? 'Detail'),
                    content: SingleChildScrollView(
                      child: Text(news[index]['body'] ?? 'Tidak ada isi berita.'),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Tutup'),
                      )
                    ],
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}