import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class BeritaPage extends StatefulWidget {
  const BeritaPage({super.key});

  @override
  State<BeritaPage> createState() => _BeritaPageState();
}

class _BeritaPageState extends State<BeritaPage> {
  List allNews = [];

  Future<void> fetchAllNews() async {
    final response = await http.get(Uri.parse('https://fakenews.squirro.com/news/sport'));
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      setState(() {
        allNews = data['news'];
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchAllNews();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Semua Berita Olahraga')),
      body: allNews.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: allNews.length,
        itemBuilder: (context, index) { // <--- PERBAIKAN: Ditambahkan ', index' di sini
          return ListTile(
            leading: const Icon(Icons.newspaper, color: Colors.green),
            title: Text(allNews[index]['title'] ?? 'No Title'),
            subtitle: Text(allNews[index]['summary'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              // Menampilkan detail berita menggunakan Dialog box
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: Text(allNews[index]['title'] ?? 'Detail'),
                  content: SingleChildScrollView(
                    child: Text(allNews[index]['body'] ?? 'Tidak ada isi.'),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Kembali'),
                    )
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}