import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UAS Mobile',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      // Memanggil halaman SplashScreen yang ada di file Splash_Screen.dart
      home: Splash_Screen(),
    );
  }

  Widget? Splash_Screen() {
    return null;
  }
}

class SplashScreen {
}