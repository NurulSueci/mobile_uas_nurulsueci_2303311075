package com.example.uas_nurulsuecii_2303311075

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
